# Hero Fandom
Montei uma ___simples rede___ de paginas que fala de alguns personagens fictícios bwé conhecidos como Steve Rogers, Bruce Wayne.

Usei um [framework](BootsTrap)* para o CSS, que achei dias atrás. Muito Otimizador (^_^)

---

### Autor
*Beny B Reis II*
- Email: [itsbenyreis@gmail.com](mailto:itsbenyreis@gmail.com)

- Redes sociais: [@bkapa8](https://www.instagram.com/bkapa8) or também [@bybenb](https://www.instagram.com/bybenb)


---

__Licença__: Este projeto está protegido por uma [__licença personalizada__](LICENSE) (_é curta,  então leia_ ^_^ ). Todos os
direitos reservados a __Beny B. Reis II__.

